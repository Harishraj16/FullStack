export default function Footer(){
    return <div className="py-4 bg-secondary text-center text-white">&copy; JVLcode 2024</div>
}